package yami


trait Quu {
  def Enque();

}